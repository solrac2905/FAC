import os
from tqdm import tqdm
from personalizado import deteccion_objetos

def video_a_imagenes(path_video):    
    os.makedirs("Imagenes_a_procesar")
    os.system("apt-get update --yes && apt-get install ffmpeg --yes")
    os.system("ffmpeg -i path_video -vf fps=1 Imagenes_a_procesar/imagen_%04d_seg.jpg")
    
def etiquetar():
    os. makedirs("Imagenes_procesadas")
    os. makedirs("resultados")
    os.system('pip install --upgrade pip')
    os.system('pip3 install opencv-python cython pillow>=7.0.0 numpy>=1.18.1 opencv-python>=4.1.2 torch>=1.9.0 --extra-index-url     https://download.pytorch.org/whl/cpu torchvision>=0.10.0 --extra-index-url https://download.pytorch.org/whl/cpu pytest==7.1.3 tqdm==4.64.1 scipy>=1.7.3 matplotlib>=3.4.3 mock==4.0.3')
    os.system('apt-get update --yes && apt-get install libgl1 --yes')
    
    result=[]

    for img in tqdm(imagenes):

        try:

            sec = float(img.split("_")[1])

            if sec < 60:
                sec = sec
                nota = "_seg"
            else:
                div = sec/60
                entero = int(div)
                segundo = sec-entero*60
                sec = str(entero) + ":" + str(segundo)
                nota = "_minuto:segundo"

            detector = deteccion_objetos()
            detector.setModelPath("yolov3_objetos_para_detectar_mAP-0.04876_epoch-62.pt")
            detector.setJsonPath("objetos_para_detectar_yolov3_detection_config.json")
            detector.loadModel()

            detections = detector.detectObjectsFromImage(input_image = "Imagenes_a_procesar" + img, output_image_path = "Imagenes_procesadas" + sec + nota + "_detectado.jpg")

            for detection in detections:
                result.append([sec + nota,detection["name"], img])

        except:
            pass
    
    results = pd.DataFrame(results, cols = ['tiempo', 'objeto', 'imagen'])
    results.to_csv("resultados/tiempo_video_y_objetos.csv", sep = "|", index = False)
    